"""Google Gemini client with JSON response mode."""

from __future__ import annotations

import os
from dataclasses import dataclass

import google.generativeai as genai
from dotenv import load_dotenv
from google.generativeai.types import GenerationConfig


class MissingApiKeyError(RuntimeError):
    pass


@dataclass
class GeminiSettings:
    api_key: str
    model: str = "gemini-2.0-flash"


def load_settings() -> GeminiSettings:
    load_dotenv()
    api_key = os.getenv("GEMINI_API_KEY", "").strip()
    if not api_key or api_key.startswith("your_"):
        raise MissingApiKeyError(
            "Set GEMINI_API_KEY in a .env file (copy .env.example). "
            "Create a key at https://aistudio.google.com/apikey"
        )
    model = os.getenv("GEMINI_MODEL", "gemini-2.0-flash").strip() or "gemini-2.0-flash"
    return GeminiSettings(api_key=api_key, model=model)


class GeminiJsonClient:
    def __init__(
        self,
        settings: GeminiSettings | None = None,
        system_instruction: str | None = None,
    ) -> None:
        self.settings = settings or load_settings()
        genai.configure(api_key=self.settings.api_key)
        self._generation = GenerationConfig(
            temperature=0.1,
            response_mime_type="application/json",
        )
        self._model = genai.GenerativeModel(
            model_name=self.settings.model,
            system_instruction=system_instruction,
            generation_config=self._generation,
        )

    def complete(self, system: str, contents: list[dict[str, str]]) -> str:
        model = genai.GenerativeModel(
            model_name=self.settings.model,
            system_instruction=system,
            generation_config=self._generation,
        )
        if len(contents) == 1:
            response = model.generate_content(contents[0]["text"])
            return (response.text or "").strip()

        history: list[dict] = []
        for turn in contents[:-1]:
            role = "user" if turn["role"] == "user" else "model"
            history.append({"role": role, "parts": [turn["text"]]})

        chat = model.start_chat(history=history)
        response = chat.send_message(contents[-1]["text"])
        return (response.text or "").strip()
